import cv2 
import numpy as np
import fourierDesciptor as fd
import pyautogui
from GestureAPI import * 
from PIL import Image, ImageFilter
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
import matplotlib.pyplot as plt
finger_thresh_l=2.0
finger_thresh_u=3.8
radius_thresh=0 # 最小手势半径在整个图像宽度的占比
first_iteration=True
finger_ct_history=[0,0]
global finger_x_before
global finger_y_before
global finger_x 
global finger_y 
#########椭圆肤色检测模型##########
kernel = np.ones((3,3), np.uint8) #设置卷积核
def binaryMask(frame, x0, y0, width, height):
	cv2.rectangle(frame,(x0,y0),(x0+width, y0+height),(0,255,0)) #画出截取的手势框图
	roi = frame[y0:y0+height, x0:x0+width] #获取手势框图
	cv2.imshow("roi", roi) #显示手势框图
    #rem = removebackground(roi)
	res = skinMask1(roi) #进行肤色检测
    #res = skinMask2(skinMask1(roi)) #进行肤色检测
    #res3 = skinMask1(roi)
	#cv2.imshow("res", res) #显示肤色检测后的图像
	res1 = cv2.erode(res, kernel) #腐蚀操作
	res2 = cv2.dilate(res1, kernel)#膨胀操作
	#cv2.imshow("res2", res2) #显示肤色检测后的图像
	return res2
def cnt_area(cnt):
    area = cv2.contourArea(cnt)
    return area
def findcontour(res):
    binaryimg = cv2.Canny(res, 50, 200) #二值化，canny检测
    h = cv2.findContours(binaryimg,cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE)
    contour = h[0]
    contour.sort(key = cnt_area, reverse=True)
    ret = np.ones(res.shape, np.uint8) #创建黑色幕布
    res = cv2.drawContours(ret, contour[0], -1, (255,255,255), 1)
    return res
# 移除视频数据的背景噪声
def removebackground(frame):
    fgbg = cv2.createBackgroundSubtractorMOG2() # 利用BackgroundSubtractorMOG2算法消除背景
    # fgmask = bgModel.apply(frame)
    fgmask = fgbg.apply(frame)
    # kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    # res = cv2.morphologyEx(fgmask, cv2.MORPH_OPEN, kernel)
    kernel = np.ones((3, 3), np.uint8)
    fgmask = cv2.erode(fgmask, kernel, iterations=1)
    res = cv2.bitwise_and(frame, frame, mask=fgmask)
    return res
########Cr，Cb范围筛选法###########
def skinMask1(roi):
	YCrCb = cv2.cvtColor(roi, cv2.COLOR_BGR2YCR_CB) #转换至YCrCb空间
	(y,cr,cb) = cv2.split(YCrCb) #拆分出Y,Cr,Cb值
    # 高斯滤波, cr 是待滤波的源图像数据, (5,5)是值窗口大小, 0 是指根据窗口大小来计算高斯函数标准差
	cr1 = cv2.GaussianBlur(cr, (5,5), 0)
    # 根据OTSU算法求图像阈值, 对图像进行二值化
	_, skin = cv2.threshold(cr1, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU) #Ostu处理
	res = cv2.bitwise_and(roi,roi, mask = skin)
	return res
########Cr，Cb范围筛选法###########
def skinMask2(roi):
	low = np.array([0, 48, 50]) #最低阈值
	high = np.array([20, 255, 255]) #最高阈值
	hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV) #转换到HSV空间
	mask = cv2.inRange(hsv,low,high) #掩膜，不在范围内的设为255
	res = cv2.bitwise_and(roi,roi, mask = mask) #图像与运算
	return res
####YCrCb颜色空间的Cr分量+Otsu法阈值分割算法
def skinMask(roi):
	YCrCb = cv2.cvtColor(roi, cv2.COLOR_BGR2YCR_CB) #转换至YCrCb空间
	(y,cr,cb) = cv2.split(YCrCb) #拆分出Y,Cr,Cb值
    # 高斯滤波, cr 是待滤波的源图像数据, (5,5)是值窗口大小, 0 是指根据窗口大小来计算高斯函数标准差
	cr1 = cv2.GaussianBlur(cr, (5,5), 0)
    # 根据OTSU算法求图像阈值, 对图像进行二值化
	_, skin = cv2.threshold(cr1, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU) #Ostu处理
	res = cv2.bitwise_and(roi,roi, mask = skin)
    #res1 = skinMask1(res)
	return res
# 4. Detect & mark fingers监测标记手指
def mark_fingers(frame_in,hull,pt,radius):
    global first_iteration
    global finger_ct_history
    finger=[(hull[0][0][0],hull[0][0][1])]#初始化
    onefinger = False #是否只有一跟手指的标志
    fivefinger = False
    okfinger = False
    j=0#手指数目

    cx = pt[0]#手中心的位置
    cy = pt[1]
    
    for i in range(len(hull)):#每个凸包 逆时针分析互相距离大于某个值  记录凸包
        dist = np.sqrt((hull[-i][0][0] - hull[-i+1][0][0])**2 + (hull[-i][0][1] - hull[-i+1][0][1])**2)
        if (dist>18):
            if(j==0):
                finger=[(hull[-i][0][0],hull[-i][0][1])]
            else:   
                finger.append((hull[-i][0][0],hull[-i][0][1]))
            j=j+1#手指数目加一
    
    temp_len=len(finger)#手指数目
    i=0
    while(i<temp_len):#计算到手中心的距离 长度范围判断 最后一个单纯y判断
        dist = np.sqrt( (finger[i][0]- cx)**2 + (finger[i][1] - cy)**2)
        if(dist<finger_thresh_l*radius or dist>finger_thresh_u*radius or finger[i][1]>cy+radius):
            finger.remove((finger[i][0],finger[i][1]))
            temp_len=temp_len-1
        else:
            i=i+1        
    
    temp_len=len(finger)#手指数目 大于5 全部无效 不显示
    if(temp_len>5):
        for i in range(1,temp_len+1-5):
            finger.remove((finger[temp_len-i][0],finger[temp_len-i][1]))
    
    palm=[(cx,cy),radius]#手掌数组

    if(first_iteration):#增加可靠性 如果是第一次调用
        finger_ct_history[0]=finger_ct_history[1]=len(finger)
        first_iteration=False
    else:#多次调用 3个平均【0】现在
        finger_ct_history[0]=0.34*(finger_ct_history[0]+finger_ct_history[1]+len(finger))

    if((finger_ct_history[0]-int(finger_ct_history[0]))>0.8):#舍入
        finger_count=int(finger_ct_history[0])+1
    else:
        finger_count=int(finger_ct_history[0])

    finger_ct_history[1]=len(finger)#这次的值【为下次调用准备】

    count_text="FINGERS:"+str(finger_count)#输出
    cv2.putText(frame_in,count_text,(int(0.62*frame_in.shape[1]),int(0.88*frame_in.shape[0])),cv2.FONT_HERSHEY_DUPLEX,1,(0,255,255),1,8)

    for k in range(len(finger)):#画圈
        cv2.circle(frame_in,finger[k],10,255,2)
        cv2.line(frame_in,finger[k],(cx,cy),255,2)
        if((finger_count==1)or(finger_count==2)):   #当只有一个手指时
            onefinger = True
            fivefinger = False
            okfinger = False
        elif(finger_count==5):
            onefinger = False
            fivefinger = True
            okfinger = False
        elif(finger_count==0):
            onefinger = False
            fivefinger = False
            okfinger = True
        else: 
            onefinger = False
            fivefinger = False
            okfinger = False
    return frame_in,finger,palm,onefinger,pt,fivefinger,okfinger

# 5. Mark hand center circle 找手的中心圆

def mark_hand_center(frame_in,cont):    #最初的翻转图像和轮廓
    max_d=0
    pt=(0,0)
    x,y,w,h = cv2.boundingRect(cont) #（最小的矩形把图像包起来）x，y是矩阵左上点的坐标，w，h是矩阵的宽和高
    for ind_y in range(int(y+0.3*h),int(y+0.8*h)): #around 0.25 to 0.6 region of height (Faster calculation with ok results)
        for ind_x in range(int(x+0.3*w),int(x+0.6*w)): #around 0.3 to 0.6 region of width (Faster calculation with ok results)
            dist= cv2.pointPolygonTest(cont,(ind_x,ind_y),True)#返回点到轮廓线的最短距离 外侧是负的
            if(dist>max_d):
                max_d=dist
                pt=(ind_x,ind_y)#（最短距离的最大值，找到手的半径）
    if(max_d>radius_thresh*frame_in.shape[1]):#（判定有效）
        thresh_score=True
        cv2.circle(frame_in,pt,int(max_d),(255,0,0),2)#绘制圆形
    else:
        thresh_score=False
    return frame_in,pt,max_d,thresh_score

# 6. Find and display gesture

def find_gesture(frame_in,finger,palm):#手指 手中心和手半径
    frame_gesture.set_palm(palm[0],palm[1])
    frame_gesture.set_finger_pos(finger)
    frame_gesture.calc_angles()
    gesture_found=DecideGesture(frame_gesture,GestureDictionary)#确定手势
    gesture_text="GESTURE:"+str(gesture_found)
    cv2.putText(frame_in,gesture_text,(int(0.56*frame_in.shape[1]),int(0.97*frame_in.shape[0])),cv2.FONT_HERSHEY_DUPLEX,1,(0,255,255),1,8)
    return frame_in,gesture_found

# 7. Remove bg from image移除背景图像

def remove_bg(frame):
    fg_mask=bg_model.apply(frame)#按b进行实例化后 输出8位二进制前景蒙版图像 前景保留 背景为黑
    frame1=fg_mask

    kernel = np.ones((3,3),np.uint8)#
    fg_mask=cv2.erode(fg_mask,kernel,iterations = 1)#形态学操作腐蚀 原图像 操作核 腐蚀次数为1 黑色增多
    frame=cv2.bitwise_and(frame,frame,mask=fg_mask)#图像与运算 为黑的地方删掉 仅包含前景
    return frame

def imageprepare(): 
    im = Image.open('D:/教材/图像处理/Mycode/readwrite/readwrite/new.png') #读取的图片所在路径，注意是28*28像素
    #plt.imshow(im)  #显示需要识别的图片
    plt.show()
    im = im.convert('L')
    tv = list(im.getdata()) 
    tva = [(255-x)*1.0/255.0 for x in tv] 
    return tva

finger_x_before = 0
finger_y_before = 0
finger_x = 0
finger_y = 0
first_x = 0
first_y = 0
write = '0'
flag_first = True
saveflag = True
img = np.zeros((560,560,3), np.uint8)
img[:] = [255,255,255]
cv2.namedWindow('image')
cap = cv2.VideoCapture(0)
GestureDictionary=DefineGestures() #初始化手势字典 3个手势
frame_gesture=Gesture("frame_gesture")#实例化 name为frame_gesture

xs = tf.placeholder(tf.float32, [None, 784]) #取出一块？*（28*28）的区域用于存放数据
ys = tf.placeholder(tf.float32, [None, 47]) #取出一块？*47的区域用于存放标签


xs_cut = tf.reshape(xs, [-1, 28, 28, 1]) #将xs形状改变为四维数组，第一维自动计算
#训练网络
conv1 = tf.layers.conv2d(inputs=xs_cut,
                         filters=32,
                         kernel_size=(3, 3),
                         strides=1,
                         activation=tf.nn.relu,
                         padding='same') #?*28*28*32
pool1 = tf.layers.max_pooling2d(inputs=conv1,
                                pool_size=(2, 2),
                                strides=2,
                                padding='same') #?*14*14*32
conv2 = tf.layers.conv2d(inputs=pool1,
                         filters=64,
                         kernel_size=(2, 2),
                         strides=1,
                         activation=tf.nn.relu,
                         padding='same') #?*14*14*64
conv3 = tf.layers.conv2d(inputs=conv2,
                         filters=128,
                         kernel_size=(2, 2),
                         strides=1,
                         activation=tf.nn.relu,
                         padding='valid') #?*13*13*128
pool2 = tf.layers.max_pooling2d(inputs=conv3,
                                pool_size=(2,2),
                                strides=2,
                                padding='same') #?*7*7*128
re1 = tf.reshape(pool2,[-1,7*7*128]) #将pool2的数组rehape为[?,7*7*128]
flat1 = tf.layers.dense(inputs=re1,
                        units=1024,
                        activation=tf.nn.relu)
# flat2 = tf.layers.batch_normalization(flat1)
flat3 = tf.layers.dense(inputs=flat1,
                        units=47)
out = tf.nn.softmax(flat3)

#训练网络#
cross_entropy = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(labels = ys,logits=flat3)) #使用交叉熵设置损失函数
train = tf.train.MomentumOptimizer(1e-3,momentum=0.5).minimize(cross_entropy) #降低损失函数

keep_prob = tf.placeholder("float")
correct = tf.equal(tf.argmax(flat3, 1), tf.argmax(ys, 1))
compute_accuracy = tf.reduce_mean(tf.cast(correct, tf.float32))


sess_config = tf.ConfigProto()
sess_config.gpu_options.per_process_gpu_memory_fraction = 0.70
saver = tf.train.Saver()
class_mapping = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabdefghnqrt'
while(1):
    # 读取帧
    _, frame = cap.read()

    frame_nobg= removebackground(frame)
    frame1 = skinMask(frame_nobg)
    frame_original = frame1
    res = binaryMask(frame_nobg,10,10,400,450)
    cv2.imshow("test", res)
    #ret = findcontour(res)
    #binaryimg = cv2.Canny(res, 50, 200) #二值化，canny检测
    #binary,h = cv2.findContours(binaryimg,cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE) #寻找轮廓
    #contours = h[1] #提取轮廓
    #ret = np.ones(res.shape, np.uint8) #创建黑色幕布
    #cv2.drawContours(ret,binary,-1,(255,255,255),1) #绘制白色轮廓
    
    #binary,contours  = cv2.findContours(binaryimg, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    #ret = np.ones(res.shape, np.uint8) #创建黑色幕布
    #res = cv2.drawContours(ret, binary, -1, (255,255,255), 1)
    ret1, fourier_result,contour_array = fd.fourierDesciptor(res)
    hand_convex_hull=cv2.convexHull(contour_array)#对最大轮廓的点集找凸包 返回每个凸包坐标组成的数组
    frame,hand_center,hand_radius,hand_size_score=mark_hand_center(frame_nobg,contour_array)#绘制手掌圆形 中心 半径 有效判定
    if(hand_size_score):#有效
        frame,finger,palm,onefinger,pt,fivefinger,okfinger=mark_fingers(frame,hand_convex_hull,hand_center,hand_radius)#标记手指
        if(onefinger):

            finger_x = pt[0]
            finger_y = pt[1] 
            if(flag_first):
                first_x = finger_x
                first_y = finger_y
                flag_first = False
                saveflag=False
                cv2.circle(img,(200-(finger_x-first_x),200+(finger_y-first_y)),16,(0,0,0),-1)
            elif(((finger_x-finger_x_before)**2+(finger_y-finger_y_before)**2)>200):
                #cv2.circle(img,(300-(finger_x),-120+(finger_y)),15,(0,0,0),-1)
                #cv2.circle(img,(300-(finger_x+finger_x_before)//2,-120+(finger_y+finger_y_before)//2),15,(0,0,0),-1)
                cv2.circle(img,(200-(finger_x-first_x),200+(finger_y-first_y)),16,(0,0,0),-1)
                #cv2.circle(img,(200-(finger_x+finger_x_before-2*first_x)//2,200+(finger_y+finger_y_before-2*first_y)//2),16,(0,0,0),-1)
                #cv2.circle(img,(200-(finger_x+finger_x_before-2*first_x)//2,100+(finger_y+finger_y_before-2*first_y)//2),16,(0,0,0),-1)
                cv2.line(img,(200-(finger_x-first_x),200+(finger_y-first_y)),((200-(finger_x_before-first_x)),(200+(finger_y_before-first_y))),(0,0,0),32)
            #print(((finger_x-finger_x_before)**2+(finger_y-finger_y_before)**2))
            #cv2.circle(img,(400-2*((finger_x+finger_x_before)//3),200+2*((finger_y+finger_y_before)//3)),10,(0,0,255),-1)
            finger_x_before = finger_x
            finger_y_before = finger_y
            
        elif(okfinger):
            if(saveflag==False or (cv2.waitKey(1) == ord('q')& 0xFF)):
                img0 = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
                img0 = cv2.bitwise_not(img0)
                x,y,w,h = cv2.boundingRect(img0) #（最小的矩形把图像包起来）x，y是矩阵左上点的坐标，w，h是矩阵的宽和
                #cv2.rectangle(img0, (x, y), (x+w, y+h), (255, 255, 0), 5)
                img2 = np.zeros((280,280,3), np.uint8)
                img2[:] = [255,255,255]
                img0 = cv2.bitwise_not(img0)
                img0 = cv2.cvtColor(img0,cv2.COLOR_GRAY2BGR)
                #img2[(140-w//2):(140-(w//2)+w),(140-h//2):(140-(h//2)+h)] = img0[x:x+w,y:y+h]
                img2[(140-h//2):(140-(h//2)+h),(140-w//2):(140-(w//2)+w)] = img0[y:y+h,x:x+w]
                cv2.imshow('2',img2)
                cv2.imshow('1',img0)
                besmall = cv2.resize(img2,None,fx=0.1, fy=0.1, interpolation = cv2.INTER_AREA)
                besmall = cv2.flip(besmall,1)
                # cols-1 和 rows-1 是坐标限制
                M = cv2.getRotationMatrix2D(((28-1)/2.0,(28-1)/2.0),90,1)
                besmall = cv2.warpAffine(besmall,M,(28,28))
                test,besmall = cv2.threshold(besmall,127,255,cv2.THRESH_BINARY)
                cv2.imwrite('new.png',besmall)
                cv2.imshow("besmall",besmall)
                saveflag=True
                result=imageprepare()
                
                with tf.Session() as sess:
                    sess.run(tf.global_variables_initializer())
                    saver.restore(sess, "D:/教材/图像处理/Mycode/train/SAVE/model.ckpt") #使用模型，参数和之前的代码保持一致         测试图像需要镜像向左转90度

                    prediction=tf.argmax(flat3,1)
                    predint=prediction.eval(feed_dict={xs: [result],keep_prob: 1.0}, session=sess)

                    print('识别结果:')
                    print(predint[0],class_mapping[predint[0]])
                    write = class_mapping[predint[0]]
        elif(fivefinger):
            saveflag=False         
            flag_first = True
            img = np.zeros((560,560,3), np.uint8)
            img[:] = [255,255,255]
            finger_x_before = 0
            finger_y_before = 0
    cv2.putText(frame,write,(int(0.8*frame.shape[1]),int(0.3*frame.shape[0])),cv2.FONT_HERSHEY_DUPLEX,4,(0,255,255),1,32)                
        #frame,gesture_found=find_gesture(frame,finger,palm)#寻找手势
    #img = cv2.flip(img,1)`
    cv2.imshow("image",img)
    cv2.imshow("ret1", ret1)
    #cv2.imshow("frame_nobg", frame_nobg)
    #cv2.imshow('frame1',frame1)
    cv2.imshow('Hand Gesture Recognition v1.0',frame)
    k = cv2.waitKey(5) & 0xFF
    if k == 27:
        break
cv2.destroyAllWindows()
